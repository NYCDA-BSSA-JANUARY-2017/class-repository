var query = require('synchronous-user-input');

var age = query("Please input your age: ");

if(age > 35) {
	console.log("time to have a midlife crisis and buy that corvette. Good luck with the divorce!");
} else if(age > 21) {
	console.log("the government thinks that you are an adult! good luck D:");
} else {
	console.log("youth is wasted on the young.");
}

// Part 1
// Augment this program so that if you are above the age of 65, it prints out: "good work! time to retire!".

// Part 2
// Augment this program so that if you are below the age of 10, it prints out: "congratulations on reaching double digits!"