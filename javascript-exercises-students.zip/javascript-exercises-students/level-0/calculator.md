note: needs testing

# Creating a calculator application for the browser

## Part 1: HTML
The HTML lays out the site, specifying its appearance and the elements that the user can interact with.

#### 1.
Create a file called "index.html".

#### 2.
Create a table with 4 rows and 4 columns.
http://www.w3schools.com/html/html_tables.asp

#### 3.
In each cell of the table, add a button (16 buttons total).

#### 4.
Label each button as follows:

```
[7][8][9][/]
[4][5][6][*]
[1][2][3][-]
[0][C][=][+]
```

Note: "C" is for 'clear'

#### 5.
Give each button an id.
Numbered buttons should have an id of "button_X", where X is the corresponding number.

```
C should have an id of "clear_button".
/ should have an id of "divide_button".
* should have an id of "multiply_button".
- should have an id of "subtract_button".
+ should have an id of "add_button".
= should have an id of "equals_button"
```

#### 6.
Create a paragraph tag with an id of "display" at the top of the page. This mimics a calculator's display and will show the user's inputs as they're typing them, as well as the result. Set the content of the display tag to `0`.

#### 7.
Check that your html looks appropriate (a `0` at the top of the page, followed by a grid of 16 buttons).

#### 8.
In your `head` tag, add two script tags. The first will contain `jQuery`, a commonly used library for frontend development. The second will contain your scripts.

Add them as follows:

```html
<script src="https://code.jquery.com/jquery-2.2.1.min.js"></script>
<script src="calculator.js"></script>
```

### Part 2: JavaScript
The JavaScript provides the wiring which gives the site functionality.

#### 1.
Create a file called "calculator.js" and put it in the same directory as your html file.

#### 2.
All your code must go inside a:

```js
$(document).ready(function() {
  // all code in here
});
```

#### 3. holding the input values
Create a variable named "x" and another variable named "y". These will hold the input values for the user. Initialize these values to `""` as follows:

```js
var x = "";
var y = "";
```

#### 4. handling click events
Create a click handler for "button_7, i.e.

```js
$('#button_7').click(function() {
  
});
```

Now, whenever someone clicks button_7, the function inside the click handler will execute.
Inside this click handler, do the following: `x = x + "7";`

Then, do:

```js
$("#display").html(x);
```

This will update the calculator's display to contain the input value.

Try clicking the `7` button several times in the browser. See that `77777` appears in the input.

#### 5.
Repeat this process for all the other numbered buttons.

#### 6. the `C` (clear) button
Create a click handler for the 'C' button.
Inside the click handler, do the following:

```js
x = "";
y = "";
```

#### 7. the `+` button
Create a click handler for the `+` button.
Inside the click handler, do the following:

```js
if(x.length > 0) {
    y = x;
    x = "";
}
```

This moves the value in `x` to `y` and resets `x`. That way, when the user clicks more numbers, the `x` value will be able to fetch them.

#### 8.
Create a new variable named `operator` next to where you created `x` and `y`.
This will store the math operation that the user clicked.

#### 9. the `+` button (continued)
Inside the click handler for the `+` button, add the line:

```js
operator = 'addition';
```

The idea is that once the user finishes adding numbers and clicks the `=` button, we can look at this variable to figure out what operation to perform.

#### 10.
Repeat steps 6 and 8 for the other operator buttons, i.e. `-`, `*`, and `/`.

#### 11. the `=` button
Create a click handler for the `=` button. Inside the click handler, do the following:

```js
var result = parseInt(x) + parseInt(y);
$("#display").html(result);
```
#### 12. the `=` button (continued)
Also in the handler, add code to reset the values of `x` and `y` back to `""`. The `C` button has similar code.

#### 13. the `=` button (continued)
Modify this statement: `var result = parseInt(x) + parseInt(y);` to do more than just addition. It should check the value of `operator` and perform the appropriate operation.

```js
var result;
if(operator === "addition") {
    result = parseInt(x) + parseInt(y);
} else if(operator === "subtraction") {
    result = parseInt(x) - parseInt(y);
} else if(...) // the rest is not shown
```

Make sure the if-else chain contains a case for each of the four operations.

#### 14. testing
Test each of the numbered buttons to make sure they work. Also test each of the operations. If everything works correctly, congratulations!