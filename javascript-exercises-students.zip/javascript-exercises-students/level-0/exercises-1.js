/* Level 0.1 */
// write a function that takes in three parameters and returns the sum of those three parameters




/* level 0.1 */
// write a function that takes in an array and returns the length of the array

// Level 0.1

// create a function that takes in a string and prints out a greeting.
// e.g. Charles --> "Hi, Charles!"

// Level 0.1
// Write a function that prints a single asterisk.



// Level 0.1

// Write a function that takes in two strings and returns the two concatenated
// together. You may not use any String functions.
// example: "abra", "cadabra" returns "abracadabra"

/*************/
/* Level 0.1 */
/*************/

// Write a function that takes in a number and returns the negative of that number.
// example: 5 ---> -5

// Level 0.2
// create a function that takes in one string as a parameter and returns that parameter concatenated.
// together three times.

// examples:
// "a" ---> "aaa"
// "beep" ---> "beepbeepbeep"


/* Level 0.2 */

// Write a function that, given a string, "doubles" it. For example, "bun" becomes "bunbun".
// Print out the doubled string to the console.

// Level 0.4

// create a function that takes in two parameters: "word" and "character".
// The function should surround the word with the character, i.e.
//"apple", "*" ---> "*apple*"
//"beep", "_" ---> "_beep_"
//"basic", "Q" ---> "QbasicQ"


// Level 0.7
// Write a function that takes in one parameter "length" and prints out that many stars.

// example:
// 3 --> ***
// 5 --> *****
