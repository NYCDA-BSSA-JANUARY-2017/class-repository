// level 0.4

// given a string, create a function that returns the last character in that string.
// examples:
// "cattywampus" --> s


/* Level 0.5 */

/**
 * "create a simple CRUD app that takes in a user's location,
 * then determines the least expensive way to travel to any
 * other location within a time constraint of their choice.
 * include an option to ensure that the trip is handicap accessible."
 */

// or

// write a function that returns the area of a circle, given the radius
// Note: Use Math.PI

/* Level 0.8 */
// write a function that takes in one parameter and returns the cube of that parameter

// Level 0.8

// Write a function that takes in an array of strings and returns all of them
// concatenated together. You may not use any String functions.
// example:
// ["abra", "cadabra"] returns "abracadabra"
// ["a", "b", "c"] returns "abc"


/* level 0.9 */
// write a function that, given an array of both letters and numbers, returns a new array that contains only the letters from the first array.

// Level 0.9
// create a function that takes in two strings and prints out the first letter in each of them.

// examples:
// "happy", "face" ---> "hf"
// "abra", "cadabra" ---> "ac"
