// starting with these clues, determine how to print out each color in the array.
