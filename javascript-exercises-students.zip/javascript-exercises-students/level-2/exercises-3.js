// level 1.5
// Write a function that, given a sorted array of integers, finds whether a certain integer is present. Return the index of that integer if it is present, and return -1 if it is not

// level 2.5
// Take the previous function, and figure out how to find a given element without looking at all of them. Hint: remember that the array is sorted.

// level 3
// write a function that, given N cities, determines the shortest route between all of them. Assume that a city is represented by coordinates (x,y).
