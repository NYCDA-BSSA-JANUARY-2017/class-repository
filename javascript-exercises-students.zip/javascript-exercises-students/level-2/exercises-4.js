// Level 2

// Write a function that takes in two arrays of integers and returns the largest
// common integer. If there are no common integers, return 'undefined'.
// example:
// [5, 10, 2], [3, 5, 7] returns 5
// [8, 7, 6], [1, 2, 8, 200] returns 8

// Level 2

// create an algorithm that accurately simulates paper crumpling

// OR

// given two rectangles located in space that may or may not be intersecting,
// compute the rectangle that results.
// rectangles are defined as: { x, y, w, h}
// x,y starts at the bottom left

/*

 (x, y+h)   (x+h, y+h)
 _____________
 |             |
 |_____________|
 (x, y)    (x+w, y)

 _______
 |       |
 |    ___|__
 |   |   |  |
 |   |   |  |
 --------  |
 |      |
 |      |
 ------
 */