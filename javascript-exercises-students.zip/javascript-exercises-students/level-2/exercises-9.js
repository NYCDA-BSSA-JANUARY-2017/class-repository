// Level 2

// Create a function that prints out a martini glass.

// Example Output: printGlass(4);

// 0000000
//  00000
//   000
//    0
//    |
//    |
//    |
//    |
// =======

// Example Output: printGlass(5);

// 000000000
//  0000000
//   00000
//    000
//     0
//     |
//     |
//     |
//     |
// =========

