// level 2

// given two arrays that contain integers with possible duplicates, create a function that determines
// if all the integers present in one array are present in the other, and vice versa
// examples:
// [1, 2, 3, 3, 3], [3, 2, 1] --> true
// [1, 2, 3], [2, 3, 4] --> false
// [1, 1, 1, 1], [1] --> true

// implement the Array#map function
// https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/map
// don't use any array functions

