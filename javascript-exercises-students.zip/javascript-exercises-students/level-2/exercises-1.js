/* Level 2 */
// write a function that takes in one parameter "n" and returns the nth prime number


/* Level */
// Compute all the times where the minute hand and hour hand are aligned. (12:00 is one of them.)
