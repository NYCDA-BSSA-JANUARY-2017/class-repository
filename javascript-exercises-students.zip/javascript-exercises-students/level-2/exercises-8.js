// Level 1

// You are a CEO of a major corporation, and you need to come up with a sophisticated
// algorithm to assist you in making decisions. Create a function that returns
// true 50% of the time and false 50% of the time.


// console.log(half());
// console.log(half());

// Level 1.5

// Modify this function so that it takes in an array as a parameter and returns a single
// element in this array in a way that's evenly distributed. In other words, each element
// is equally likely to be returned.




// Level 2

// Create a test suite that tests this function.

// Level 2

// Create a test suite that tests this function.
