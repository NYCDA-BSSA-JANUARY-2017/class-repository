// Level 2.5
// Given Q quarters, D dimes, N nickels, and P pennies, determine whether it is possible to make
// X amount of change. Return a hash (Ruby) / or object (JavaScript) containing which permutation
// of change satisfies this condition.
// extra: find the one that takes the fewest number of coins.