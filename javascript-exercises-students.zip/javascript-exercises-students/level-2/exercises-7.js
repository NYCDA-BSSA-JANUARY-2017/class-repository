// Level 2

// given n sorted arrays, combine them all into a single sorted array. Include all duplicates.
// constraints: you're only allowed to iterate through them once.
// ps. no array functions that iterate through the array (i.e. indexOf)

// Level 2

// compute the first n Pythagorean triangles
