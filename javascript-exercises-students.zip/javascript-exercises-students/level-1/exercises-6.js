


// Level 1

// create a function that takes in three booleans as parameters. If any two are
// true and one is false, return true. Otherwise, return false.
// e.g.
// true, true, false --> true
// true, false, false --> false
// true, false, true --> true
// false, false, false ---> false


// Level 1.3

// create a function that computes the distance between two points.
// the formula for distance is "the square root of ('x' squared plus 'y' squared").
// assume points are represented as objects of the form { x: value, y: value }
// Hint: use the Math library
// e.g.
// { x: 3, y: 4 } --> 5
// { x: 1, y: 1 } --> 1.414


