/* Level 1.5 */
// write a function that takes in an array of strings and sends all of them a greeting.
// e.g. ["Sarah", "Faraday", "Stafford"]
// prints out "Hi Sarah, Faraday, and Stafford!"
// other examples:
// ["Butt", "Nose"]
// prints out "Hi Butt and Nose!"
// ["A", "B", "C", "D", "E", "F"]
// prints out "Hi A, B, C, D, E, and F!"

/* Level 1.9 */
// write a function that takes in two parameters, x and n, and computes x to the nth power
// you may not use Math.* functions
