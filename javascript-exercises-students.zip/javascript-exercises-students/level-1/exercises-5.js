/* morning exercise */

/* level 1 */
// write a function that determines the ‘nth’ triangle number.
/**
 * For example, f(4) = 10 and f(5) = 15
 * A triangle number is the number of
 * dots in a given triangle (shown below)
 *    .
 *   . .
 *  . . .
 * . . . .
 * imagine bowling pins
 */

// Write a function that checks a Sudoku row for correctness


// Level 1

// Write a function that takes in two integers and returns the one which is
// closest to 0. If they are the same distance from 0, return either of them.
// example:
// 2, 3 returns 2
// -5, 6 returns -5
// -1, -1 returns -1
