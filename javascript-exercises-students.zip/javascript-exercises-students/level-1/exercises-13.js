// write a function that takes in two arrays of the same length as parameters. From those two arrays,
// create, then return an object which contains the elements of the first array as keys, and the
// elements of the second array as values.
// examples:
// ["terrible", "twos"], ["fabulous", "fours"] --> { terrible: "twos", fabulous: "fours" }
// ["a", "b", "c"], ["x", "y", "z"] --> { a: "x", b: "y", c: "z" }

// Given an object with keys and values, create two arrays: one which contains the object's keys,
// and one which contains the object's values. Wrap this into a function which takes in one object
// that contains keys and values, and returns a different object that contains two keys. The first key
// should be named "keys" and will have the first array as a value. The second key should be named
// "values" and will have the second array as a value.
// examples:
// { terrible: "twos", fabulous: "fours" } --> { keys: ["terrible", "twos"], values: ["fabulous", "fours"] }
// { a: "x", b: "y", c: "z" } --> { keys: ["a", "b", "c"], values: ["x", "y", "z"] }

// level 1
// Write a function that takes in two parameters:
// an array that contains integers,
// a number, "x".
// Return a new array that contains the only the numbers in the original that
// were divisible by "x".


//
// Given a paragraph of text, write a function that finds the most common word.