
// Level 1
// Write a function that takes in one parameter "length" prints out a square of that length.
// example:

// 3 --> ***
//       ***
//       ***

// 5 --> *****
//       *****
//       *****
//       *****
//       *****

// Level 1.5
// Write another function in the same vein that prints out a right triangle instead.

// 4 --> ****
//       ***
//       **
//       *

// Level 1.6
// Now do, like, a diamond or whatever. The parameter defines a length of one side.

// 3 -->   *
//        ***
//       *****
//        ***
//         *

// 4 -->   *
//        ***
//       *****
//      *******
//       *****
//        ***
//         *



// Level 3
// Now do this thing.
// https://en.wikipedia.org/wiki/Golden_spiral#/media/File:Fibonacci_spiral_34.svg
// (fyi idk how to do it)



// like this i guess lol but dynamic and stuff
//
//
//
//        ****
//    *          *
//  *              *
// *                 *
//
//                    *
//       ****
//     *      *
//    *    *  *       *
//    *     **       *
//                  *
//      *        *
//         ****
//
