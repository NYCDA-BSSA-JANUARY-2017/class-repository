// level 1

// define a function that takes in an array of numbers as a parameter and returns
// the largest value in that array. (you may not use the .max() function)

// level 1.5

// define a function that takes in a string and reverses it. you are not allowed to
// call the "reverse" function (or any other string functions)
// hint:

// create a function that takes in one parameter, a string. The function should reverse the first half of the string, and also the second half of the string. If the string has an odd number of characters, leave the middle character alone. Return the new string.

// examples:
// "abcdefgh" becomes "dcbahgfe"
// "12345678" becomes "43218765"
// "abbab" becomes "babba"
// "1234567" becomes "3214765"
// "_.-^-._" becomes "-._^_.-"



// level 2

// given an array of integers, return that array, sorted. You may not use the "sort"
// function or any other array functions

