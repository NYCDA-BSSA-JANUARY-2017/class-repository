// Level 1

// write a function that takes in an array of numbers and checks
// whether each number is less than the previous one.
// Return true if all of them fit this condition.







// Level 1.5

// write comprehensive tests for this function


