/*************/
/* Level 1.5 */
/*************/

// write a function that takes in a math operator as a string followed by two parameters, x and y, then
// return the result of that math operation applied to the two parameters.
// examples:
// math("*", 2, 3) ---> 6
// math("+", 4, 5) ---> 9

// bonus: instead of passing in the operation as a string
// pass it as a function that takes two parameters.
