/**
 * level 1
 *
 * Implement an "equals with epsilon" function. The function should check if two numbers are
 * equal within a certain margin of error. The function should take in three parameters: the
 * two values to compare, and an "epsilon" value that determines the error margin. The function
 * should return true or false.
 *
 * You are not allowed to use any "Math.*" functions.
 * examples:
 * 10, 11, epsilon 0.5 ---> false
 * 10, 10.2, epsilon 0.3 ---> true
 */
 
/**
 * level 1.5
 *
 * Write a function that, given a string, return an object that contains each key as a letter
 * and the number of times it appears in the string as the value.
 * examples:
 * "start" --> { s: 1, t: 2, a: 1, r: 1 }
 * "fuzzlewuzzle" --> { f: 1, u: 2, z: 4, l: 2, e: 2, w: 1 }
 */

/**
 * level 1.6
 *
 * Write a function that, given three numbers, determine return true if two of the numbers
 * are “close” and one is “far”, otherwise return false.
 * Numbers are "close" if they are within 0.1 of each other.
 * examples:
 * 1,   2,   3:   false
 * 1,   1.1, 3:   true
 * 1,   1.1, 1.2: false
 * 9.5, 2,   9.6: true
 */