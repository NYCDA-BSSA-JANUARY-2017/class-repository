// Level 1

// given an array of integers, write a function that finds the average and returns it.
// examples:
// [1,2,3] --> 2
// [1,2,4] --> 2.3333

// i created a function that takes in one parameter, which is an array
// i created a variable equal to the length of the array.
// in that function, i looped through the array and added up each of the numbers in the array
// that number got stored in a variable
// then, i divided that number by the length of the array, and returned the result


// Level 1

// You're trying to create a paginator that splits up your items into pages.
// First, given a total number of items, determine how many pages you need to create
// if there's supposed to be 50 items on a page.

// examples:
// 45 --> 1
// 100 --> 2
// 101 --> 3