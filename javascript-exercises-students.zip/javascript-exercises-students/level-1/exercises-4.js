/*************************/
/* morning exercises! :D */
/*************************/


/* Level 1 */
// Determine whether a given string is a palindrome. "radar", "racecar", "kayak" are all palindromes.

/* Level 1.5 */
// Take your previous function and upgrade it: account for spaces and punctuation.
// So, for example, "A man, a plan, a canal: Panama" now counts as a palindrome.
