// Level 1
// create a function that determines the nth fibonacci number. A fibonacci number is defined as
// the sum of the previous two fibonacci numbers, i.e. the sequence goes 0, 1, 1, 2, 3, 5, 8, 13, 21 ...

// examples:
// fibonacci(1) returns 0
// fibonacci(5) returns 3
// fibonacci(8) returns 13
