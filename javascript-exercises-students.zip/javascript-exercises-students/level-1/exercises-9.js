// level 1.5

// given two arrays that contain integers with no duplicates, create a function that determines
// whether they contain the exact same elements.
// examples:
// [1, 2, 3], [3, 2, 1] --> true
// [1, 2, 3], [2, 3, 4] --> false